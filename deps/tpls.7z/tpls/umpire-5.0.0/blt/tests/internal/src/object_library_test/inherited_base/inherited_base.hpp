// Copyright (c) 2017-2019, Lawrence Livermore National Security, LLC and
// other BLT Project Developers. See the top-level COPYRIGHT file for details
//
// SPDX-License-Identifier: (BSD-3-Clause)

#ifndef INHERITED_OBJECT_HPP
#define INHERITED_OBJECT_HPP

int inherited_number();

#endif
