## CAMP Concepts And Meta-Programming library

This project collects a variety of macros and metaprogramming facilities for C++
projects.  It's in the direction of projects like metal (a major influence) but
with a focus on wide compiler compatibility across HPC-oriented systems.
