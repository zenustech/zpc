==========
Allocators
==========

Allocators are the fundamental object used to allocate and deallocate memory
using Umpire.

.. doxygenclass:: umpire::Allocator

.. doxygenclass:: umpire::TypedAllocator
