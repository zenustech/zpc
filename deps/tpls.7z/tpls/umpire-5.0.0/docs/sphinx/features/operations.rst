.. _operations:

==========
Operations
==========

Operations provide an abstract interface to modifying and moving data between
Umpire :class:`umpire::Allocator`s. 

-------------------
Provided Operations 
-------------------

.. doxygennamespace:: umpire::op
